<?php
header('Content-Type: application/json');

$conn = new mysqli("localhost","iot_user","iot_pass","iot_car");

// kiểm tra kết nối
if ($conn->connect_error) {
    echo json_encode([
        "mode" => "ERROR",
        "distance" => 0,
        "battery" => 0
    ]);
    exit;
}

// lấy mode
$modeRow = $conn->query("SELECT mode FROM control WHERE id = 1");
$mode = $modeRow ? $modeRow->fetch_assoc()["mode"] : "--";

// lấy distance + battery mới nhất
$dataRow = $conn->query("SELECT distance, battery FROM log_data ORDER BY id DESC LIMIT 1");
$data = $dataRow ? $dataRow->fetch_assoc() : null;

echo json_encode([
    "mode" => $mode,
    "distance" => $data["distance"] ?? 0,
    "battery" => $data["battery"] ?? 0
]);
