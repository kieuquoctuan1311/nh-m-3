import mysql.connector
from gpiozero import Motor
from evdev import InputDevice, ecodes
import RPi.GPIO as GPIO
import threading, time, sys, signal
import board, busio
from adafruit_ina219 import INA219

running = True
lock = threading.Lock()

state = {"lx": 0.0, "ly": 0.0}
cur   = {"mode": "MANUAL", "dist": 0.0, "l": 0.0, "r": 0.0}

DEADZONE = 0.15
AUTO_SPEED = 0.4 

i2c = busio.I2C(board.SCL, board.SDA)
ina = INA219(i2c)

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

TRIG, ECHO = 23, 24
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.output(TRIG, False)

def get_db():
    return mysql.connector.connect(
        host="localhost",
        user="iot_user",
        password="iot_pass",
        database="iot_car",
        autocommit=True,
        connection_timeout=5
    )

def get_cursor():
    db = get_db()
    return db, db.cursor(buffered=True)

def record_start():
    try:
        db = get_db()
        c = db.cursor()
        c.execute("INSERT INTO system_time(start_time) VALUES (NOW())")
        db.close()
    except:
        pass

def record_end():
    try:
        db = get_db()
        c = db.cursor()
        c.execute("""
            UPDATE system_time
            SET end_time = NOW()
            WHERE end_time IS NULL
            ORDER BY id DESC
            LIMIT 1
        """)
        db.close()
    except:
        pass

left1  = Motor(6, 5)
left2  = Motor(16, 12)
right1 = Motor(21, 20)
right2 = Motor(26, 19)

def get_battery_percent():
    try:
        v = ina.bus_voltage
        i = abs(ina.current)
        if i < 5:
            return 0
        p = (v - 9.9) / (12.6 - 9.9) * 100
        return int(max(0, min(100, p)))
    except:
        return 0

def stop_all():
    left1.stop(); left2.stop()
    right1.stop(); right2.stop()

def set_side(l, r):
    if abs(l) < DEADZONE: l = 0
    if abs(r) < DEADZONE: r = 0
    if l > 0:
        left1.forward(l); left2.forward(l)
    elif l < 0:
        left1.backward(-l); left2.backward(-l)
    else:
        left1.stop(); left2.stop()
    if r > 0:
        right1.forward(r); right2.forward(r)
    elif r < 0:
        right1.backward(-r); right2.backward(-r)
    else:
        right1.stop(); right2.stop()

def get_distance():
    GPIO.output(TRIG, False)
    time.sleep(0.002)
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    timeout = time.time() + 0.03
    while GPIO.input(ECHO) == 0:
        if time.time() > timeout:
            return cur["dist"]

    start = time.time()
    timeout = time.time() + 0.03
    while GPIO.input(ECHO) == 1:
        if time.time() > timeout:
            return cur["dist"]

    d = (time.time() - start) * 17150
    if 2 < d < 400:
        return round(d, 1)
    return cur["dist"]
def distance_loop():
    while running:
        with lock:
            cur["dist"] = get_distance()
        time.sleep(0.1)

def get_mode():
    try:
        db, c = get_cursor()
        c.execute("SELECT mode FROM control WHERE id=1")
        r = c.fetchone()
        db.close()
        return r[0].strip().upper() if r else "MANUAL"
    except:
        return "MANUAL"

def mode_loop():
    while running:
        try:
            with lock:
                cur["mode"] = get_mode()
        except:
            pass
        time.sleep(0.1)

def joystick_loop():
    dev = InputDevice("/dev/input/by-id/usb-Togran_DAREU_H105_Receiver_XInput_00000000-event-joystick")
    dev.grab()
    for e in dev.read_loop():
        if not running:
            break
        if e.type == ecodes.EV_ABS:
            if e.code in (ecodes.ABS_X, ecodes.ABS_RX):
                state["lx"] = e.value / 32768.0
            elif e.code in (ecodes.ABS_Y, ecodes.ABS_RY):
                state["ly"] = e.value / 32768.0

def motor_loop():
    while running:
        if cur["mode"] != "MANUAL":
            time.sleep(0.05)
            continue

        lx, ly = state["lx"], state["ly"]

        if abs(lx) < DEADZONE:
            lx = 0
        if abs(ly) < DEADZONE:
            ly = 0

        l = max(-1, min(1, -ly + lx))
        r = max(-1, min(1, -ly - lx))

        with lock:
            cur["l"], cur["r"] = l, r

        if l == 0 and r == 0:
            stop_all()
        else:
            set_side(l, r)

        time.sleep(0.05)
def auto_loop():
    AUTO_SPEED = 0.4

    while running:
        if cur["mode"] != "AUTO":
            time.sleep(0.05)
            continue

        d = cur["dist"]
        if d < 8:
            l = -AUTO_SPEED
            r = -AUTO_SPEED
            set_side(l, r)
            time.sleep(0.3)

            if random.choice([True, False]):
                l = -AUTO_SPEED
                r = AUTO_SPEED
            else:
                l = AUTO_SPEED
                r = -AUTO_SPEED

            set_side(l, r)
            time.sleep(0.4)
        elif 8 <= d <= 15:
            l = AUTO_SPEED * 0.6
            r = AUTO_SPEED * 0.6
            set_side(l, r)

        # XA
        else:
            l = AUTO_SPEED
            r = AUTO_SPEED
            set_side(l, r)

        with lock:
            cur["l"] = l
            cur["r"] = r

        time.sleep(0.1)
def log_loop():
    while running:
        try:
            db, c = get_cursor()
            battery = get_battery_percent()
            with lock:
                d = cur["dist"]
                l = cur["l"]
                r = cur["r"]
            c.execute(
                "INSERT INTO log_data(distance,battery,speed_left,speed_right) VALUES (%s,%s,%s,%s)",
                (d, battery, l, r)
            )
            db.close()
        except:
            pass
        time.sleep(1)

def safe_exit(a, b):
    global running
    running = False
    record_end()
    stop_all()
    GPIO.cleanup()
    sys.exit(0)

record_start()

signal.signal(signal.SIGINT, safe_exit)
signal.signal(signal.SIGTERM, safe_exit)

threading.Thread(target=mode_loop, daemon=True).start()
threading.Thread(target=joystick_loop, daemon=True).start()
threading.Thread(target=motor_loop, daemon=True).start()
threading.Thread(target=auto_loop, daemon=True).start()
threading.Thread(target=distance_loop, daemon=True).start()
threading.Thread(target=log_loop, daemon=True).start()

while running:
    time.sleep(1)
