<?php
header('Content-Type: application/json');

$mysqli = new mysqli("localhost", "iot_user", "iot_pass", "iot_car");
if ($mysqli->connect_error) {
    echo json_encode([]);
    exit;
}

$sql = "
    SELECT 
        DATE_FORMAT(created_at,'%H:%i:%s') AS time,
        distance,
        battery
    FROM log_data
    ORDER BY id DESC
    LIMIT 20
";

$res = $mysqli->query($sql);

$data = [];
while ($row = $res->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode(array_reverse($data));
