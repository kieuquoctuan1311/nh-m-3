<?php
header('Content-Type: application/json');

$mysqli = new mysqli("localhost","iot_user","iot_pass","iot_car");
if ($mysqli->connect_error) {
    echo json_encode(null);
    exit;
}

$sql = "
SELECT 
    DATE_FORMAT(start_time,'%Y-%m-%d %H:%i:%s') AS start,
    DATE_FORMAT(end_time,'%Y-%m-%d %H:%i:%s') AS end
FROM system_time
ORDER BY id DESC
LIMIT 1
";

$res = $mysqli->query($sql);
$row = $res ? $res->fetch_assoc() : null;

echo json_encode($row);
