<?php
header('Content-Type: application/json');

$mysqli = new mysqli("localhost", "iot_user", "iot_pass", "iot_car");
if ($conn->connect_error) {
    echo json_encode(["status" => "db_error"]);
    exit;
}

// nhận dữ liệu từ GET hoặc POST
$distance = isset($_REQUEST['distance']) ? (int)$_REQUEST['distance'] : 0;
$battery  = isset($_REQUEST['battery'])  ? (int)$_REQUEST['battery']  : 0;
$mode     = isset($_REQUEST['mode'])     ? $_REQUEST['mode']          : 'AUTO';

// cập nhật mode
$conn->query("UPDATE control SET mode='$mode' WHERE id=1");

// ghi log
$stmt = $conn->prepare("INSERT INTO log_data(distance, battery) VALUES (?, ?)");
$stmt->bind_param("ii", $distance, $battery);
$stmt->execute();

echo json_encode([
    "status" => "ok",
    "distance" => $distance,
    "battery" => $battery,
    "mode" => $mode
]);
