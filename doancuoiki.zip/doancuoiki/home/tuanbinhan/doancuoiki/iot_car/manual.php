<?php
$mysqli = new mysqli("localhost", "iot_user", "iot_pass", "iot_car");
if ($mysqli->connect_error) {
    http_response_code(500);
    exit;
}
$mysqli->query("UPDATE control SET mode='MANUAL' WHERE id=1");
echo "OK";
